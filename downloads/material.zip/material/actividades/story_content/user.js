function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6REW6BopEx5":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

